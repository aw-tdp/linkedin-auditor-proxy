# LinkedIn Profile Auditor

A 42-point LinkedIn profile audit tool for business owners and professionals focused on lead gen, outreach, and organic content growth. Upload a PDF screenshot of any LinkedIn profile and receive a full audit with graded findings, specific recommendations, and downloadable CSV and PDF reports.

---

## Project structure

```
linkedin-auditor/
├── proxy/          ← Node.js backend (calls Anthropic API)
│   ├── server.js
│   ├── package.json
│   ├── vercel.json
│   └── .env.example
└── frontend/       ← Standalone HTML frontend (no build step)
    └── index.html
```

---

## Step 1 — Deploy the proxy server

The proxy server sits between your browser and the Anthropic API. It keeps your API key secure server-side.

### Option A — Deploy to Vercel (recommended, free)

1. Install the Vercel CLI if you haven't already:
   ```bash
   npm install -g vercel
   ```

2. Navigate to the proxy folder:
   ```bash
   cd proxy
   npm install
   ```

3. Deploy:
   ```bash
   vercel
   ```
   Follow the prompts. When asked about settings, accept the defaults.

4. Set your Anthropic API key as an environment variable in Vercel:
   - Go to your project on vercel.com
   - Settings → Environment Variables
   - Add: `ANTHROPIC_API_KEY` = your key from console.anthropic.com

5. Redeploy to pick up the env var:
   ```bash
   vercel --prod
   ```

6. Copy your deployment URL — it will look like `https://linkedin-auditor-proxy.vercel.app`

### Option B — Deploy to Railway (also free tier)

1. Push the `/proxy` folder to a GitHub repo
2. Go to railway.app → New Project → Deploy from GitHub
3. Select the repo
4. Add environment variable: `ANTHROPIC_API_KEY`
5. Railway auto-detects Node and deploys. Copy the generated URL.

### Option C — Run locally (for testing)

```bash
cd proxy
npm install
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
npm run dev
```

Your local proxy URL will be `http://localhost:3001`

---

## Step 2 — Open the frontend

The frontend is a single HTML file with no build step or dependencies.

Simply open `frontend/index.html` in any browser. That's it.

For production use, you can host `frontend/index.html` on:
- **Vercel** — drag the file into vercel.com/new
- **Netlify** — drag into netlify.com/drop
- **GitHub Pages** — push to a repo and enable Pages
- **Any static host** — it's just one HTML file

---

## Step 3 — Use the tool

1. Open `index.html` in your browser
2. Paste your proxy server URL into the "Proxy server URL" field
3. Upload a LinkedIn profile PDF (see below for how to create one)
4. Click **Run audit**
5. Review the 42-point audit in the browser
6. Download as CSV (opens in Excel) or PDF Report

---

## How to create a LinkedIn profile PDF

1. Open the LinkedIn profile in Chrome or Edge
2. Scroll through the entire profile to expand all sections
3. Press `Ctrl+P` (Windows) or `Cmd+P` (Mac)
4. Change destination to **Save as PDF**
5. Set layout to **Portrait**
6. Click Save

Multi-page PDFs are fully supported. The more of the profile that is visible, the more complete the audit.

---

## What the audit covers

The 42-point framework covers:

**Positioning & First Impressions** — photo, banner, headline, custom URL, creator mode, Open to Work frame, location, pronouns

**Content & Copywriting** — About section hook, body copy, ICP clarity, CTA, formatting, Featured section, experience descriptions, activity and post cadence

**Trust & Credibility** — recommendations (quantity and quality), reciprocity, skills, endorsements, education, certifications, awards, volunteering, connection count

**Commercial Strategy** — headline as value proposition, CTA specificity, Featured section as conversion tool, contact info, company page, narrative consistency, ICP alignment

**Technical & Visibility** — profile completeness, keyword placement in headline and About, skills alignment, public visibility, engagement signals

---

## Costs

Each audit uses approximately 6,000–9,000 tokens with Claude Sonnet.
At current Anthropic pricing this is roughly $0.04–$0.06 per audit.

---

## Environment variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ANTHROPIC_API_KEY` | Yes | Your key from console.anthropic.com |
| `PORT` | No | Defaults to 3001 |

---

## Tech stack

- **Frontend** — Vanilla HTML/CSS/JS, no framework, no build step
- **Proxy** — Node.js, Express, @anthropic-ai/sdk
- **AI** — Claude claude-sonnet-4-5 via Anthropic API
- **PDF processing** — Anthropic's native document API (no OCR library needed)
